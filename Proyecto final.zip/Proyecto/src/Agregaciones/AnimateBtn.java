package Agregaciones;

import Panel_gradiend.PanelGradient;
import Vista.Agregar;
import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.JLabel;


public class AnimateBtn {

    private void mostrarColor(PanelGradient paneX, PanelGradient paneZ, JLabel lblx, String url) {
        paneX.setBackground(new Color(52, 100, 174));//Color a mostrar
        paneZ.setColorGradient(new Color(59, 207, 255));//Color a mostrar
        lblx.setForeground(Color.WHITE);//Color de texto a mostrar

        lblx.setIcon(new ImageIcon(getClass().getResource(url)));//Cambiar icono a blanco
    }

    private void establecColor(PanelGradient paneX, PanelGradient paneZ, JLabel lblx, String url) {
        paneX.setBackground(new Color(23, 27, 36));//Color por defecto
        paneZ.setColorGradient(new Color(23, 27, 36));//Color por defecto
        lblx.setForeground(new Color(166, 166, 166));//Color de texto por defecto

        lblx.setIcon(new ImageIcon(getClass().getResource(url)));//Cambiar icono a gris
    }

    public void AnimatHome() {
        mostrarColor(Agregar.btnHome, Agregar.btnHome, Agregar.lblHome, "/Imagenes/home.png");
        establecColor(Agregar.btnSalir, Agregar.btnSalir, Agregar.lblSalir, "/Imagenes/salir.png");
    }


    public void AnimattSalir() {
        mostrarColor(Agregar.btnSalir, Agregar.btnSalir, Agregar.lblSalir, "/Imagenes/salir.png");
       establecColor(Agregar.btnHome, Agregar.btnHome, Agregar.lblHome, "/Imagenes/home.png");
    }
}
