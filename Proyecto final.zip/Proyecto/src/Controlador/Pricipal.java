
package Controlador;

import Vista.Agregar;
import Vista.Login;
import Vista.pnlHome;
import java.io.IOException;
import javax.swing.LookAndFeel;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

public class Pricipal {
    public static void main(String[] args) throws IOException {
         new Login().setVisible(true);
    }
 
}