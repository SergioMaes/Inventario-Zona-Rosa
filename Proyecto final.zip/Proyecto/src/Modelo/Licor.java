package Modelo;

public abstract class Licor {

    protected String Nombre;
    protected String Presentacion;
    protected String AnioElaboracion;
    protected float ContAzucar;
    protected String Color;
    protected String Origen;
    protected byte[] Imagen;
    protected String Tipo;

    protected Licor() {
    }

    public Licor(String Nombre, String Presentacion, String AnioElaboracion, float ContAzucar, String Color, String Origen, byte[] Imagen, String Tipo) {
        this.Nombre = Nombre;
        this.Presentacion = Presentacion;
        this.AnioElaboracion = AnioElaboracion;
        this.ContAzucar = ContAzucar;
        this.Color = Color;
        this.Origen = Origen;
        this.Imagen = Imagen;
        this.Tipo = Tipo;
    }

}
