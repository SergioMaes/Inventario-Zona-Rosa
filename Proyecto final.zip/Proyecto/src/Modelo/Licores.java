
package Modelo;

import java.util.ArrayList;


public class Licores extends Licor {

    public Licores() {
    }

    public Licores(String Nombre, String Presentacion, String AnioElaboracion, float ContAzucar, String Color, String Origen, byte[] Imagen, String Tipo) {
        super(Nombre, Presentacion, AnioElaboracion, ContAzucar, Color, Origen, Imagen, Tipo);
    }
    
    
    
    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getPresentacion() {
        return Presentacion;
    }

    public void setPresentacion(String Presentacion) {
        this.Presentacion = Presentacion;
    }

    public String getAnioElaboracion() {
        return AnioElaboracion;
    }

    public void setAnioElaboracion(String AnioElaboracion) {
        this.AnioElaboracion = AnioElaboracion;
    }

    public float getContAzucar() {
        return ContAzucar;
    }

    public void setContAzucar(float ContAzucar) {
        this.ContAzucar = ContAzucar;
    }

    public String getColor() {
        return Color;
    }

    public void setColor(String Color) {
        this.Color = Color;
    }

    public String getOrigen() {
        return Origen;
    }

    public void setOrigen(String Origen) {
        this.Origen = Origen;
    }

    public byte[] getImagen() {
        return Imagen;
    }

    public void setImagen(byte[] Imagen) {
        this.Imagen = Imagen;
    }

    public String getTipo() {
        return Tipo;
    }

    public void setTipo(String Tipo) {
        this.Tipo = Tipo;
    }
 
     public String CalcularTipo() {
        if (ContAzucar < 4) {
            Tipo = "Seco";
        } else if ((ContAzucar >= 4) && (ContAzucar <= 12)) {
            Tipo = "Abocado";
        } else if ((ContAzucar > 12) && (ContAzucar <= 30)) {
            Tipo = "Semiseco";
        } else if ((ContAzucar > 30) && (ContAzucar <= 50)) {
            Tipo = "Semidulce";
        } else {
            Tipo = "Dulce";
        }
        return Tipo;
    }
}
