package Modelo;

import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

public class Persistencia {

    //Metodo para guardar
    public static void Guardar(ArrayList<Licores> ListVinos) throws IOException {
        try (DataOutputStream dos = new DataOutputStream( new FileOutputStream("Vinos.bin"))) {
            for (Licores I : ListVinos) {
                dos.writeUTF(I.getNombre());
                dos.writeUTF(I.getPresentacion());
                dos.writeUTF(I.getAnioElaboracion());
                dos.writeFloat(I.getContAzucar());
                dos.writeUTF(I.getColor());
                dos.writeUTF(I.getOrigen());
                dos.writeInt(I.getImagen().length);
                dos.write(I.getImagen());
                dos.writeUTF(I.getTipo());
            }
        }
    }

    //Metodo para leer
    public static ArrayList<Licores> Leer() throws FileNotFoundException, IOException {
        ArrayList<Licores> ListVinos = new ArrayList<Licores>();
        try (DataInputStream dis = new DataInputStream(new FileInputStream("Vinos.bin"))) {
                
            while (dis.available() > 0) {
                    String nombre = dis.readUTF();
                    String presen = dis.readUTF();
                    String anio = dis.readUTF();
                    float cont = dis.readFloat();
                    String color = dis.readUTF();
                    String origen = dis.readUTF();
                    int tmImagen = dis.readInt();//leer la longitud de la imagen
                    byte[] imagen = new byte[tmImagen];
                    dis.readFully(imagen);//leer todos los bytes de la imagen
                    String tipo = dis.readUTF();
                    
                    Licores vino = new Licores(nombre, presen, anio, cont, color, origen, imagen, tipo);
                    ListVinos.add(vino);
                }
            
        } 
        catch (EOFException ex) {
        }

        return ListVinos;
    }
    
    
}

