
package Vista;

import Agregaciones.TextPrompt;
import Modelo.Persistencia;
import Modelo.Licores;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import static javax.swing.JOptionPane.WARNING_MESSAGE;
import static javax.swing.JOptionPane.YES_NO_OPTION;
import javax.swing.RowFilter;
import javax.swing.RowSorter;
import javax.swing.SortOrder;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

/**
 *
 * @author 57304
 */
public class pnlHome extends javax.swing.JPanel{
DefaultTableModel modelo = new DefaultTableModel ();
    ArrayList<Licores> allVinos = new ArrayList<Licores>();
    private byte[] miImagen;
     int filas;
     TableRowSorter trs;
     TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(modelo); 
     
   
    public pnlHome() {
        initComponents();
        modelo = (DefaultTableModel) tblVinos.getModel();
        allVinos = new ArrayList<Licores>();
        verTabla();
        TextPrompt placeholder = new TextPrompt("Buscar",txtBuscar);
        sorter = new TableRowSorter<>(modelo);
        tblVinos.setRowSorter(sorter);
        EsconderBtn();
        
        //Ordenar jtable
        cboTipoOr.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                filtrarPorTipo();
            }
        });
   }


  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtBuscar = new javax.swing.JTextField();
        cboPresentacion = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        jycAnioElaboracion = new com.toedter.calendar.JYearChooser();
        jLabel6 = new javax.swing.JLabel();
        txtContAzucar = new javax.swing.JTextField();
        cboColor = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        txtOrigen = new javax.swing.JTextField();
        txtNombreVino = new javax.swing.JTextField();
        lblImg = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblVinos = new javax.swing.JTable();
        btnRefresh = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        btnImagen = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        btnOrdenarN = new javax.swing.JButton();
        cboTipoOr = new javax.swing.JComboBox<>();

        setBackground(new java.awt.Color(255, 204, 255));
        setPreferredSize(new java.awt.Dimension(700, 460));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtBuscar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 153, 153), new java.awt.Color(102, 102, 102), new java.awt.Color(204, 204, 204), new java.awt.Color(51, 51, 51)));
        txtBuscar.setOpaque(true);
        txtBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtBuscarActionPerformed(evt);
            }
        });
        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtBuscarKeyTyped(evt);
            }
        });
        add(txtBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 40, 140, 20));

        cboPresentacion.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Barril", "Botella" }));
        cboPresentacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboPresentacionActionPerformed(evt);
            }
        });
        add(cboPresentacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 300, 164, -1));

        jLabel5.setBackground(new java.awt.Color(204, 204, 204));
        jLabel5.setFont(new java.awt.Font("Kristen ITC", 0, 12)); // NOI18N
        jLabel5.setText("Fecha ");
        add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 340, 100, -1));
        add(jycAnioElaboracion, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 360, 164, -1));

        jLabel6.setBackground(new java.awt.Color(204, 204, 204));
        jLabel6.setFont(new java.awt.Font("Kristen ITC", 0, 12)); // NOI18N
        jLabel6.setText("Stock");
        add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 340, 76, -1));

        txtContAzucar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtContAzucarActionPerformed(evt);
            }
        });
        add(txtContAzucar, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 360, 164, -1));

        cboColor.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Whisky", "Aguardiente", "Cerveza" }));
        cboColor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboColorActionPerformed(evt);
            }
        });
        add(cboColor, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 420, 164, -1));

        jLabel7.setBackground(new java.awt.Color(204, 204, 204));
        jLabel7.setFont(new java.awt.Font("Kristen ITC", 0, 12)); // NOI18N
        jLabel7.setText("Tipo de bebida");
        add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 400, 100, -1));

        jLabel9.setBackground(new java.awt.Color(204, 204, 204));
        jLabel9.setFont(new java.awt.Font("Kristen ITC", 0, 12)); // NOI18N
        jLabel9.setText("Origen");
        add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 400, 57, -1));

        txtOrigen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtOrigenActionPerformed(evt);
            }
        });
        add(txtOrigen, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 420, 164, -1));

        txtNombreVino.setBackground(new java.awt.Color(204, 204, 204));
        txtNombreVino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreVinoActionPerformed(evt);
            }
        });
        add(txtNombreVino, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 300, 164, -1));

        lblImg.setBackground(new java.awt.Color(255, 102, 255));
        lblImg.setForeground(new java.awt.Color(51, 51, 51));
        lblImg.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Camara 2 (1).png"))); // NOI18N
        lblImg.setText("  ");
        add(lblImg, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 40, 130, 120));

        jLabel3.setBackground(new java.awt.Color(204, 204, 204));
        jLabel3.setFont(new java.awt.Font("Kristen ITC", 0, 12)); // NOI18N
        jLabel3.setText("Nombre");
        add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 280, 57, -1));

        jLabel4.setBackground(new java.awt.Color(204, 204, 204));
        jLabel4.setFont(new java.awt.Font("Kristen ITC", 0, 12)); // NOI18N
        jLabel4.setText("Cantidad de contenido");
        add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 280, 130, -1));

        tblVinos.setBackground(new java.awt.Color(255, 153, 255));
        tblVinos.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        tblVinos.setFont(new java.awt.Font("Kristen ITC", 0, 14)); // NOI18N
        tblVinos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Nombre", "Presentacion", "Año", "Stock", "Tipo"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        tblVinos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblVinosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblVinos);

        add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 60, 400, 160));

        btnRefresh.setText("Refresh");
        btnRefresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRefreshActionPerformed(evt);
            }
        });
        add(btnRefresh, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 320, 90, 30));

        btnGuardar.setBackground(new java.awt.Color(255, 102, 204));
        btnGuardar.setFont(new java.awt.Font("Kristen ITC", 0, 14)); // NOI18N
        btnGuardar.setText("Agregar");
        btnGuardar.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(204, 0, 153)));
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });
        add(btnGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 390, 160, 30));

        btnImagen.setText("Seleccionar Imagen");
        btnImagen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnImagenActionPerformed(evt);
            }
        });
        add(btnImagen, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 160, 164, 30));

        btnModificar.setText("Modificar");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });
        add(btnModificar, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 320, 90, 30));

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });
        add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 390, 90, 30));

        jLabel8.setBackground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Imagen Del Producto");
        add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 20, -1, -1));

        btnOrdenarN.setText("Ordenar");
        btnOrdenarN.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnOrdenarNMouseClicked(evt);
            }
        });
        add(btnOrdenarN, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 230, 90, 30));

        cboTipoOr.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Todos", "Whiskys", "Aguardientes", "Cervezas" }));
        cboTipoOr.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboTipoOrActionPerformed(evt);
            }
        });
        add(cboTipoOr, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 230, 70, 30));
    }// </editor-fold>//GEN-END:initComponents


    void EsconderBtn() {
        btnModificar.setEnabled(false);
        btnEliminar.setEnabled(false);
        btnRefresh.setEnabled(false);
        btnGuardar.setEnabled(true);
    }
  
    private void mostrarImagenEnLabel(String ruta) {
    Image img = new ImageIcon(ruta).getImage();
    ImageIcon icon = new ImageIcon(img.getScaledInstance(lblImg.getWidth(), lblImg.getHeight(), Image.SCALE_SMOOTH));
    lblImg.setIcon(icon);
}
    
     void Aniadir() throws IOException {
        Licores vino = new Licores();
        vino.setNombre(txtNombreVino.getText());
        vino.setPresentacion( cboPresentacion.getSelectedItem().toString());
        vino.setAnioElaboracion(String.valueOf(jycAnioElaboracion.getYear())); 
        vino.setContAzucar(Float.parseFloat(txtContAzucar.getText()));
        vino.CalcularTipo();
        vino.setColor(cboColor.getSelectedItem().toString());
        vino.setOrigen(txtOrigen.getText());
        vino.setImagen(miImagen);
        allVinos.add(vino);
        
        try {
            Persistencia.Guardar(allVinos);
        } catch (IOException e) {
           JOptionPane.showMessageDialog(null, "No fue posible guardar el archivo", "Error", WARNING_MESSAGE);
        }
              
    }
    
    //Metodo para mostrar en la tabla
    void verTabla(){
        while(modelo.getRowCount() > 0){
            modelo.removeRow(0);
        }
        
       try {
    allVinos = Persistencia.Leer();
} catch (IOException ex) {
    ex.printStackTrace();
    JOptionPane.showMessageDialog(null, "Error al leer el archivo");
}

        for(Licores I: allVinos){
            Object dato[] = new Object[7];
            dato[0] = I.getNombre();
            dato[1] = I.getPresentacion();
            dato[2] = I.getAnioElaboracion();
            dato[3] = I.getContAzucar();
            dato[4] = I.getColor();
            dato[5] = I.getOrigen();
            dato[6] = I.getTipo();
            modelo.addRow(dato);
   }
        tblVinos.setModel(modelo);
    }
    
    //Metodo para limpiar las cajas
    void Limpiar() {
        txtNombreVino.setText("");
        cboPresentacion.setSelectedIndex(0);
        jycAnioElaboracion.setValue(Calendar.getInstance().get(Calendar.YEAR));
        txtContAzucar.setText("");
        cboColor.setSelectedIndex(0);
        txtOrigen.setText("");
        lblImg.setIcon(null);
        miImagen = null;
        txtNombreVino.requestFocus();
    }
    
  
    private void txtBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtBuscarActionPerformed

    }//GEN-LAST:event_txtBuscarActionPerformed

    private void txtBuscarKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarKeyTyped
        txtBuscar.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                trs.setRowFilter(RowFilter.regexFilter("(?i)" + txtBuscar.getText(), 0));
            }
        });

        trs = new TableRowSorter(modelo);
        tblVinos.setRowSorter(trs);
    }//GEN-LAST:event_txtBuscarKeyTyped

    private void cboPresentacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboPresentacionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cboPresentacionActionPerformed

    private void txtContAzucarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtContAzucarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtContAzucarActionPerformed

    private void cboColorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboColorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cboColorActionPerformed

    private void txtOrigenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtOrigenActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtOrigenActionPerformed

    private void txtNombreVinoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreVinoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreVinoActionPerformed

    private void tblVinosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblVinosMouseClicked
        modelo = (DefaultTableModel) tblVinos.getModel();
        filas = tblVinos.getSelectedRow();

        btnModificar.setEnabled(true);
        btnEliminar.setEnabled(true);
        btnRefresh.setEnabled(true);
        
        txtNombreVino.setText((String) tblVinos.getValueAt(filas, 0));
        cboPresentacion.setSelectedItem(tblVinos.getValueAt(filas, 1));
        jycAnioElaboracion.setYear(Integer.parseInt(String.valueOf(tblVinos.getValueAt(filas, 2))));
        txtContAzucar.setText(String.valueOf(Float.parseFloat(String.valueOf(tblVinos.getValueAt(filas, 3)))));
        cboColor.setSelectedItem(tblVinos.getValueAt(filas, 4));
        txtOrigen.setText((String) tblVinos.getValueAt(filas, 5));
        byte[] imagenBytes = allVinos.get(filas).getImagen();
        ImageIcon icon = new ImageIcon(imagenBytes);
        lblImg.setIcon(new ImageIcon(icon.getImage().getScaledInstance(lblImg.getWidth(), lblImg.getHeight(), Image.SCALE_SMOOTH)));
        btnGuardar.setEnabled(false);
    }//GEN-LAST:event_tblVinosMouseClicked

    private void btnRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRefreshActionPerformed
        Limpiar();
        mostrarImagenEnLabel("src/Imagenes/predeterminada.png");
        EsconderBtn();
    }//GEN-LAST:event_btnRefreshActionPerformed

    private void btnImagenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnImagenActionPerformed
        JFileChooser jf = new JFileChooser();
        FileNameExtensionFilter filtro = new FileNameExtensionFilter("png, jpg", "png", "jpg");
        jf.setFileFilter(filtro);
        jf.setMultiSelectionEnabled(false);

        String ruta = null;
        if (jf.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            ruta = jf.getSelectedFile().getPath();

            try {
                miImagen = Files.readAllBytes(Paths.get(ruta));
            } catch (IOException e) {
                e.printStackTrace();
            }
            mostrarImagenEnLabel(ruta);
        }
    }//GEN-LAST:event_btnImagenActionPerformed

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        String modNombre, modPresentacion, modAnio, modCont, modColor, modOrigen;
        modNombre = txtNombreVino.getText().toString();
        modPresentacion = cboPresentacion.getSelectedItem().toString();
        modAnio =String.valueOf(jycAnioElaboracion.getYear());
        modCont = txtContAzucar.getText();
        modColor = cboColor.getSelectedItem().toString();
        modOrigen = txtOrigen.getText();

        //Le damos los nuevos valores al arrayList
        allVinos.get(filas).setNombre(modNombre);
        allVinos.get(filas).setPresentacion(modPresentacion);
        allVinos.get(filas).setAnioElaboracion(modAnio);
        allVinos.get(filas).setContAzucar(Float.parseFloat(modCont));
        allVinos.get(filas).setColor(modColor);
        allVinos.get(filas).setOrigen(modOrigen);
        allVinos.get(filas).setTipo(allVinos.get(filas).CalcularTipo());

        //Se limpia las casillas
        modelo.setRowCount(0);

        //Ahora se muestra el array en el jtable
        for(Licores I: allVinos){
            Object[] objV = {I.getNombre(), I.getPresentacion(), I.getAnioElaboracion(), I.getContAzucar(), I.getColor(), I.getOrigen(), I.getTipo()};
            modelo.addRow(objV);
        }
        Limpiar();
        mostrarImagenEnLabel("src/Imagenes/predeterminada.png");
        
    }//GEN-LAST:event_btnModificarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        int button = JOptionPane.YES_NO_OPTION;
        int res = JOptionPane.showConfirmDialog(this, "Esta seguro de Borrar este vino de el estanco?", "Advertencia", YES_NO_OPTION);

        if (res == 0) {
            modelo.removeRow(filas);
            allVinos.remove(filas);

            try {
            Persistencia.Guardar(allVinos);
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al guardar el archivo", "Error", WARNING_MESSAGE);
        }
            //Limpiar las casillas
            modelo.setRowCount(0);
            //Actualizamos
            for (Licores I : allVinos) {
                Object[] objV = {I.getNombre(), I.getPresentacion(), I.getAnioElaboracion(), I.getContAzucar(), I.getColor(), I.getOrigen(), I.getTipo()};
                modelo.addRow(objV);
            }
            Limpiar();
            btnGuardar.setEnabled(true);
            mostrarImagenEnLabel("src/Imagenes/predeterminada.png");
            btnModificar.setEnabled(false);
            btnEliminar.setEnabled(false);
            btnRefresh.setEnabled(false);
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

        //Boton ordenar ascendnetemente por nombre
    private void btnOrdenarNMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnOrdenarNMouseClicked
 // Configurar el comparador para la columna de nombres
    Comparator<String> comparator = Comparator.reverseOrder();
    sorter.setComparator(0, comparator);

    // Ordenar de manera descendente por la columna de nombres
    sorter.setSortKeys(java.util.List.of(new RowSorter.SortKey(0, SortOrder.DESCENDING)));
    sorter.sort();
    }//GEN-LAST:event_btnOrdenarNMouseClicked

    private void cboTipoOrActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboTipoOrActionPerformed

    }//GEN-LAST:event_cboTipoOrActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        if(txtNombreVino.getText().isEmpty() || txtContAzucar.getText().isEmpty() || txtOrigen.getText().isEmpty() || miImagen == null){
            JOptionPane.showMessageDialog(this, "Por favor llene todos los campos","Error agregar", DISPOSE_ON_CLOSE);
        }
        else{
            try {
                Aniadir();
                verTabla();
                Limpiar();
                mostrarImagenEnLabel("src/Imagenes/predeterminada.png");
            } catch (IOException ex) {
            }
        }
    }//GEN-LAST:event_btnGuardarActionPerformed
 // Método para filtrar las filas del JTable según el tipo seleccionado
    private void filtrarPorTipo() {
        String tipoSeleccionado = cboTipoOr.getSelectedItem().toString();
        if ("Todos".equals(tipoSeleccionado)) {
            sorter.setRowFilter(null); // Mostrar todos los vinos
        } else {
            RowFilter<Object, Object> rowFilter = RowFilter.regexFilter(tipoSeleccionado, 6);
            sorter.setRowFilter(rowFilter);
        }
    }
    



    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnImagen;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnOrdenarN;
    private javax.swing.JButton btnRefresh;
    private javax.swing.JComboBox<String> cboColor;
    private javax.swing.JComboBox<String> cboPresentacion;
    private javax.swing.JComboBox<String> cboTipoOr;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private com.toedter.calendar.JYearChooser jycAnioElaboracion;
    private javax.swing.JLabel lblImg;
    private javax.swing.JTable tblVinos;
    private javax.swing.JTextField txtBuscar;
    private javax.swing.JTextField txtContAzucar;
    private javax.swing.JTextField txtNombreVino;
    private javax.swing.JTextField txtOrigen;
    // End of variables declaration//GEN-END:variables

}
